

Put that in your INIT.SQF


[] execVM "PVP_Zone\viewmode.sqf";
[] execVM "PVP_Zone\PVP_Respect.sqf";


Custom CODES for your config.cpp


#include "PVP_Zone\PVP_Zone_Codes.hpp"