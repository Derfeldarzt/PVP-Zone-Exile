PVPzone_checkPVPzone = "PVP_Zone\PVPzone_checkPVPzone.sqf";
onLeaveSafezone = "PVP_Zone\onLeaveSafezone.sqf";
onEnterPVPzone = "PVP_Zone\onEnterPVPzone.sqf";
isPVPZoneInRange = "PVP_Zone\isPVPZoneInRange.sqf";
isInPVPZone = "PVP_Zone\isInPVPZone.sqf";